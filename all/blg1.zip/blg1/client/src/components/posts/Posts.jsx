import "./posts.css"
import Post from "../../components/post/Post"

export default function Posts() {
  return (
    <div className="Posts">
      <Post/>
      <Post/>
      <Post/>
      <Post/>
      <Post/>
      <Post/>
      
      

    </div>
    
  )
}
